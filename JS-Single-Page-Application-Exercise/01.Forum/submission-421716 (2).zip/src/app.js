import { showHome } from "./home.js";
import { } from './eventHandlers.js'
import { } from './details.js'

showHome();
